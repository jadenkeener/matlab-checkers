function eval = minimax(depth, maximizing)
global logicBoard
global moveList

% Because I made the terrible mistake of using globals, store this for
% later
logicStore = logicBoard;
moves = moveList;

% If at bottom of depth, perform static evaluation of the board and return
% that value.
if depth == 0
    eval = 0;
    for i = 1:64
        switch logicBoard(i)
            case {1, 11}
                eval = eval+1;
            case {2, 22}
                eval = eval-1;
        end
    end
    return
end

% If we are the maximizing player, then play all of our moves and perform
% minimax on each of those children with depth-1.
if maximizing
    maxEval = -inf;
    for i = 1:length(moves)
        % We need to reload our logicBoard every time because globals lol
        logicBoard = logicStore;
        playMove(moves{i}, true)
        eval = minimax(depth-1, false);
        maxEval = max([maxEval, eval]);
    end
    return
else
    minEval = inf;
    for i = 1:length(moveList)
        logicBoard = logicStore;
        playMove(move{i}, false)
        eval = minimax(depth-1, true);
        minEval = min([minEval, eval]);
    end
    return
end



end