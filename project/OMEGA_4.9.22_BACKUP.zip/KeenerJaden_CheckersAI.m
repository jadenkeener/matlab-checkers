%% KeenerJaden_CheckersAI.m
% This machine plays checkers!
%
% TO DO:
% * Implement AI

%% Cleanup
clear;clc;


%% Initialization
% The arrays in this section only hold game information. They are not used
% to draw the game! The AI makes all choices based on the logic arrays.

% intialize board
% place pieces on board. player one (black) pieces are represented by 1 for
% pawns and 11 for kings. player two (red) pieces are 2 and 22.
%
global logicBoard
logicBoard = zeros(8,8);



% Struct containing offset values for ease of use. Contains index offsets
% to upper left/right and bottom left/right

newGame();







%% Main
% drawBoard();
generateMovesPlayer(true);
turnCounter = 0;
global logicDebug
global moveList
logicDebug = [];

% Play random legal moves!
player = false;
try
while true
    player = ~player;
    turnCounter = turnCounter + 1;
    if ~isempty(moveList{1})
        forcedMoves = moveList{1};
        playMove(moveList{forcedMoves(randi(length(forcedMoves)))}, player)
    else
        playMove(moveList{randi([2,length(moveList)])}, player);
    end
end
catch
    disp("Game over in "+turnCounter+" turns!")
    drawBoard;
end
