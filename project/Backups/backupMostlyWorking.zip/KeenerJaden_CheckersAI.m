%% KeenerJaden_CheckersAI.m
% This machine plays checkers!
%
% TO DO:
% * Implement AI

%% Cleanup
clear;clc;


%% Initialization
% The arrays in this section only hold game information. They are not used
% to draw the game! The AI makes all choices based on the logic arrays.

% intialize board
% place pieces on board. player one (black) pieces are represented by 1 for
% pawns and 11 for kings. player two (red) pieces are 2 and 22.
%
global logicBoard
logicBoard = zeros(8,8);

for r = 1:3
    for c = 1:8
        if mod(r+c, 2) == 0
            %Creating player 1 (bottom of board). Player 1 has pawns on
            %bottom three rows where r+c is even.
            logicBoard(r+5,c) = 1; 
        else
            %Creating player 2 (top of board). Player 2 has pawns on
            %top three rows where r+c is odd.
            logicBoard(r,c) = 2;
        end
    end
end

% Struct containing offset values for ease of use. Contains index offsets
% to upper left/right and bottom left/right


global offsets
offsets = struct;
offsets.ul = -9;
offsets.ur = 7;
offsets.bl = -7;
offsets.br = 9;

global moveList
moveList = {};






%% Main
% drawBoard();
generateMovesPlayer(true);
turnCounter = 0;
global logicDebug
logicDebug = [];

% Play random legal moves!
player = false;
try
while true
    player = ~player;
    turnCounter = turnCounter + 1;
    if ~isempty(moveList{1})
        forcedMoves = moveList{1};
        playMove(moveList{forcedMoves(randi(length(forcedMoves)))}, player)
    else
        playMove(moveList{randi([2,length(moveList)])}, player);
    end
end
catch
    disp("Game over in "+turnCounter+" turns!")
    drawBoard;
end
