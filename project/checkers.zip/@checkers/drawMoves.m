function drawMoves(mousePos)
    


end
